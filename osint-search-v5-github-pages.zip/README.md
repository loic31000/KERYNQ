# OSINT SEARCH 5.0

Application statique gratuite (HTML, CSS et JavaScript), sans API, serveur, suivi ni compte.

## Utilisation immédiate

Ouvrir `index.html` dans un navigateur. Le moteur sélectionné s'ouvre dans un nouvel onglet ; les recherches Web nécessitent Internet. L'interface, les filtres et la préparation de consignes fonctionnent hors ligne.

## Publication sur GitHub Pages

1. Créer un dépôt public `osint-search` sur GitHub.
2. Déposer **le contenu de ce dossier** à la racine de la branche `main` (pas le dossier parent).
3. `Settings` > `Pages` > `Build and deployment` > `Deploy from a branch` > `main` > `/(root)` > `Save`.
4. L'URL sera généralement `https://UTILISATEUR.github.io/osint-search/`.

Aucune GitHub Action personnalisée, aucun serveur, aucune clé API. GitHub exécute tout de même son infrastructure Pages automatiquement.

## Fonctionnalités

- 27 univers et filtres spécifiques, mode essentiel/avancé, raccourci Ctrl+K.
- Modèles préconfigurés et modèles personnels, favoris avec dossiers et épingles, sauvegarde import/export.
- Requêtes Google, Brave ou DuckDuckGo. Opérateurs compatibles appliqués, et distinctions explicites pour les critères de consigne IA.
- Thème clair/sombre, texte agrandi, navigation clavier, animations réduites selon les préférences de l'appareil.
- PWA installable sur navigateurs compatibles et cache local pour l'interface.

## Confidentialité et limites

Les préférences, favoris et modèles résident dans le stockage local du navigateur ; leur contenu ne se synchronise pas entre appareils. L'export JSON permet de les transférer. La recherche est transmise au moteur choisi lors de l'ouverture d'un nouvel onglet. OSINT SEARCH ne lit ni n'indexe les pages de résultats et ne vérifie pas automatiquement les faits. L'interface utilisable hors ligne ne signifie pas que Google, Brave, DuckDuckGo ou ChatGPT fonctionnent hors ligne.

La présence d'un opérateur ne garantit pas que le moteur l'applique toujours strictement. Pour une recherche rigoureuse, vérifier la page de résultats.
